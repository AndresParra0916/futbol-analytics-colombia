# %%
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import cosine_similarity
from datetime import datetime
import os
import json
import warnings
warnings.filterwarnings('ignore')

BASE = os.path.join(os.path.expanduser("~"), "Documents", "futbol-analytics-colombia")
RUTA_DATA = os.path.join(BASE, "data")
RUTA_REPORTS = os.path.join(BASE, "reports")
print("✅ Librerías cargadas")

# %%
def crear_datos_iniciales():
    equipos = ["Atlético Nacional", "Millonarios", "América de Cali", 
               "Junior", "Santa Fe", "Deportivo Cali"]
    posiciones = ["Delantero", "Mediocampista", "Defensa", "Portero"]
    nombres = [
        "Carlos Rojas", "Juan Pérez", "Andrés García", "Luis Martínez",
        "Diego López", "Sebastián Torres", "Felipe Herrera", "Camilo Ruiz",
        "Mateo Castro", "Daniel Vargas", "Santiago Mora", "Nicolás Silva",
        "Alejandro Ramos", "David Gómez", "Cristian Suárez", "Julián Ríos",
        "Iván Mendoza", "Rodrigo Pinto", "Fabio Restrepo", "Óscar Delgado",
        "Brayan Soto", "Wilmar Barrios", "Yeison Gordillo", "Kevin Mier"
    ]
    np.random.seed(42)
    jugadores = []
    for i, nombre in enumerate(nombres):
        jugadores.append({
            "nombre_real": nombre,
            "nombre": f"jugador_{i}",
            "equipo": np.random.choice(equipos),
            "posicion": np.random.choice(posiciones),
            "edad": np.random.randint(18, 35),
            "goles": np.random.randint(0, 8),
            "asistencias": np.random.randint(0, 6),
            "minutos_totales": np.random.randint(300, 900),
            "minutos_ultima_semana": 0,
            "recuperaciones": np.random.randint(5, 50),
            "duelos_ganados": np.random.randint(10, 80),
            "pases_progresivos": np.random.randint(20, 150),
            "ultima_jornada": 0,
            "fecha_actualizacion": datetime.now().strftime("%Y-%m-%d")
        })
    df = pd.DataFrame(jugadores)
    df['goles_p90'] = df['goles'] / (df['minutos_totales'] / 90)
    df['asistencias_p90'] = df['asistencias'] / (df['minutos_totales'] / 90)
    df['pases_progresivos_p90'] = df['pases_progresivos'] / (df['minutos_totales'] / 90)
    df['duelos_ganados_p90'] = df['duelos_ganados'] / (df['minutos_totales'] / 90)
    df['recuperaciones_p90'] = df['recuperaciones'] / (df['minutos_totales'] / 90)
    archivo = os.path.join(RUTA_DATA, "jugadores_liga_2024.csv")
    df.to_csv(archivo, index=False)
    print(f"✅ Datos iniciales creados: {len(df)} jugadores")
    return df

# Crear solo si no existe
archivo = os.path.join(RUTA_DATA, "jugadores_liga_2024.csv")
if not os.path.exists(archivo):
    df_base = crear_datos_iniciales()
else:
    df_base = pd.read_csv(archivo)
    print(f"✅ Datos existentes cargados: {len(df_base)} jugadores")

# %%
def simular_nueva_jornada(df, jornada_num):
    np.random.seed(jornada_num * 42)
    df_nuevo = df.copy()
    for idx in df_nuevo.index:
        posicion = df_nuevo.loc[idx, 'posicion']
        juega = np.random.random() > 0.3
        minutos_jornada = np.random.randint(45, 96) if juega else 0
        df_nuevo.loc[idx, 'minutos_totales'] += minutos_jornada
        df_nuevo.loc[idx, 'minutos_ultima_semana'] = minutos_jornada
        if juega and minutos_jornada > 0:
            if posicion == 'Delantero':
                df_nuevo.loc[idx, 'goles'] += np.random.choice([0,1,2], p=[0.7, 0.25, 0.05])
            elif posicion == 'Mediocampista':
                df_nuevo.loc[idx, 'goles'] += np.random.choice([0,1], p=[0.9, 0.1])
            df_nuevo.loc[idx, 'asistencias'] += np.random.choice([0,1], p=[0.85, 0.15])
            df_nuevo.loc[idx, 'recuperaciones'] += np.random.randint(0, 8)
            df_nuevo.loc[idx, 'duelos_ganados'] += np.random.randint(0, 12)
            df_nuevo.loc[idx, 'pases_progresivos'] += np.random.randint(0, 20)
    df_nuevo['ultima_jornada'] = jornada_num
    df_nuevo['fecha_actualizacion'] = datetime.now().strftime("%Y-%m-%d")
    return df_nuevo

def generar_reporte_visual(df, jornada):
    df_f = df[df['minutos_totales'] >= 300].copy()
    col = 'nombre_real' if 'nombre_real' in df.columns else 'nombre'
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle(f'Liga BetPlay Colombia — Jornada {jornada} | {datetime.now().strftime("%d/%m/%Y")}',
                 fontsize=14, fontweight='bold')
    top_g = df_f.nlargest(10, 'goles_p90')
    axes[0,0].barh(top_g[col], top_g['goles_p90'], color='steelblue')
    axes[0,0].set_title('Top 10 Goleadores (por 90 min)')
    top_r = df_f.nlargest(10, 'recuperaciones_p90')
    axes[0,1].barh(top_r[col], top_r['recuperaciones_p90'], color='coral')
    axes[0,1].set_title('Top 10 Recuperadores (por 90 min)')
    min_eq = df.groupby('equipo')['minutos_totales'].sum().sort_values(ascending=False)
    axes[1,0].bar(range(len(min_eq)), min_eq.values, color='green', alpha=0.7)
    axes[1,0].set_xticks(range(len(min_eq)))
    axes[1,0].set_xticklabels(min_eq.index, rotation=45, ha='right')
    axes[1,0].set_title('Minutos Totales por Equipo')
    df_f.groupby('posicion')['goles'].sum().plot(
        kind='pie', ax=axes[1,1], autopct='%1.1f%%',
        colors=['#ff9999','#66b3ff','#99ff99','#ffcc99'])
    axes[1,1].set_title('Goles por Posición')
    plt.tight_layout()
    ruta = os.path.join(RUTA_REPORTS, f'jornada_{jornada:02d}.png')
    plt.savefig(ruta, dpi=150, bbox_inches='tight')
    plt.show()
    print(f"📊 Gráfico guardado: jornada_{jornada:02d}.png")

def mostrar_tabla_posiciones(df, jornada):
    df_f = df[df['minutos_totales'] >= 300].copy()
    col = 'nombre_real' if 'nombre_real' in df.columns else 'nombre'
    print(f"\n{'='*60}\n📊 LÍDERES — JORNADA {jornada}\n{'='*60}")
    for titulo, metrica in [('⚽ Goleadores','goles_p90'),('🎯 Asistidores','asistencias_p90'),
                             ('💪 Recuperadores','recuperaciones_p90'),('🔄 Creadores','pases_progresivos_p90')]:
        print(f"\n{titulo}:")
        for i, (_, r) in enumerate(df_f.nlargest(5, metrica).iterrows(), 1):
            print(f"  {i}. {r[col]} ({r['equipo']}) — {r[metrica]:.2f}")

def guardar_historial(df, jornada):
    path = os.path.join(RUTA_DATA, "historial_jornadas.json")
    historial = json.load(open(path)) if os.path.exists(path) else {}
    col = 'nombre_real' if 'nombre_real' in df.columns else 'nombre'
    top = df.nlargest(10, 'goles_p90')[[col, 'equipo', 'goles', 'goles_p90']]
    historial[f"jornada_{jornada}"] = {"fecha": datetime.now().strftime("%Y-%m-%d"),
                                        "top_goleadores": top.to_dict('records')}
    json.dump(historial, open(path, 'w'), ensure_ascii=False, indent=2)
    print(f"📁 Historial guardado — jornada {jornada}")

def actualizar_semana():
    print("="*60)
    print(f"📅 ACTUALIZACIÓN SEMANAL — {datetime.now().strftime('%d/%m/%Y')}")
    print("="*60)
    archivo = os.path.join(RUTA_DATA, "jugadores_liga_2024.csv")
    df = pd.read_csv(archivo)
    jornada = int(df['ultima_jornada'].max()) + 1
    print(f"\n📌 Procesando Jornada {jornada}...")
    df = simular_nueva_jornada(df, jornada)
    df['goles_p90'] = df['goles'] / (df['minutos_totales'] / 90)
    df['asistencias_p90'] = df['asistencias'] / (df['minutos_totales'] / 90)
    df['pases_progresivos_p90'] = df['pases_progresivos'] / (df['minutos_totales'] / 90)
    df['duelos_ganados_p90'] = df['duelos_ganados'] / (df['minutos_totales'] / 90)
    df['recuperaciones_p90'] = df['recuperaciones'] / (df['minutos_totales'] / 90)
    df = df.replace([np.inf, -np.inf], 0).fillna(0)
    df.to_csv(archivo, index=False)
    print(f"✅ Datos guardados — Jornada {jornada}")
    generar_reporte_visual(df, jornada)
    mostrar_tabla_posiciones(df, jornada)
    guardar_historial(df, jornada)
    print(f"\n✅ Jornada {jornada} completada")
    return df

print("✅ Todas las funciones definidas")

# %%
import os
import pandas as pd
import numpy as np
from datetime import datetime

BASE = os.path.join(os.path.expanduser("~"), "Documents", "futbol-analytics-colombia")
RUTA_DATA = os.path.join(BASE, "data")

equipos = ["Atlético Nacional", "Millonarios", "América de Cali", 
           "Junior", "Santa Fe", "Deportivo Cali"]
posiciones = ["Delantero", "Mediocampista", "Defensa", "Portero"]
nombres = [
    "Carlos Rojas", "Juan Pérez", "Andrés García", "Luis Martínez",
    "Diego López", "Sebastián Torres", "Felipe Herrera", "Camilo Ruiz",
    "Mateo Castro", "Daniel Vargas", "Santiago Mora", "Nicolás Silva",
    "Alejandro Ramos", "David Gómez", "Cristian Suárez", "Julián Ríos",
    "Iván Mendoza", "Rodrigo Pinto", "Fabio Restrepo", "Óscar Delgado",
    "Brayan Soto", "Wilmar Barrios", "Yeison Gordillo", "Kevin Mier"
]

np.random.seed(42)
jugadores = []
for i, nombre in enumerate(nombres):
    jugadores.append({
        "nombre_real": nombre,
        "nombre": f"jugador_{i}",
        "equipo": np.random.choice(equipos),
        "posicion": np.random.choice(posiciones),
        "edad": np.random.randint(18, 35),
        "goles": np.random.randint(0, 8),
        "asistencias": np.random.randint(0, 6),
        "minutos_totales": np.random.randint(300, 900),
        "minutos_ultima_semana": 0,
        "recuperaciones": np.random.randint(5, 50),
        "duelos_ganados": np.random.randint(10, 80),
        "pases_progresivos": np.random.randint(20, 150),
        "ultima_jornada": 0,
        "fecha_actualizacion": datetime.now().strftime("%Y-%m-%d")
    })

df = pd.DataFrame(jugadores)
df['goles_p90'] = df['goles'] / (df['minutos_totales'] / 90)
df['asistencias_p90'] = df['asistencias'] / (df['minutos_totales'] / 90)
df['pases_progresivos_p90'] = df['pases_progresivos'] / (df['minutos_totales'] / 90)
df['duelos_ganados_p90'] = df['duelos_ganados'] / (df['minutos_totales'] / 90)
df['recuperaciones_p90'] = df['recuperaciones'] / (df['minutos_totales'] / 90)

archivo = os.path.join(RUTA_DATA, "jugadores_liga_2024.csv")
df.to_csv(archivo, index=False)
print(f"✅ Datos recreados correctamente: {len(df)} jugadores")
print(f"📁 Guardado en: {archivo}")
print(f"\nColumnas: {df.columns.tolist()}")

# %%
df_actualizado = actualizar_semana()

# %%
import sys
!{sys.executable} -m pip install selenium webdriver-manager --quiet
print("✅ Selenium instalado")

# %%
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import pandas as pd
import time

# Configurar Chrome en modo silencioso
options = Options()
options.add_argument("--headless")
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")

print("🔄 Iniciando Chrome...")
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

print("🔄 Cargando DIMAYOR...")
driver.get("https://dimayor.com.co/tabla-de-posiciones/")

# Esperar que cargue la tabla
time.sleep(5)

# Ver el HTML cargado
html = driver.page_source
soup_check = html.count('<table')
print(f"Tablas encontradas en HTML dinámico: {soup_check}")

# Intentar extraer tabla
try:
    dfs = pd.read_html(html)
    print(f"✅ {len(dfs)} tablas extraídas")
    for i, df in enumerate(dfs):
        print(f"\nTabla {i}:")
        print(df.head(5))
except Exception as e:
    print(f"Sin tablas HTML, buscando elementos...")
    filas = driver.find_elements(By.TAG_NAME, "tr")
    print(f"Filas encontradas: {len(filas)}")
    for fila in filas[:10]:
        print(fila.text)

driver.quit()
print("\n✅ Listo")

# %%
import requests
from bs4 import BeautifulSoup
import pandas as pd

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}

# ESPN tabla de posiciones Liga BetPlay
url = "https://www.espn.com.co/futbol/posiciones/_/liga/col.1"

response = requests.get(url, headers=headers)
print(f"Estado: {response.status_code}")

if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Buscar tablas
    tablas = soup.find_all('table')
    print(f"Tablas encontradas: {len(tablas)}")
    
    # Buscar cualquier dato de equipos
    equipos = soup.find_all('span', class_='hide-mobile')
    print(f"\nEquipos encontrados: {len(equipos)}")
    for e in equipos[:20]:
        print(e.text.strip())
        
    # Intentar con pandas
    try:
        dfs = pd.read_html(response.text)
        print(f"\n✅ {len(dfs)} tablas extraídas")
        print(dfs[0].head(10))
    except Exception as ex:
        print(f"\nPandas no encontró tablas: {ex}")
else:
    print(f"❌ Error: {response.status_code}")

# %%
import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
from datetime import datetime

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}

BASE = os.path.join(os.path.expanduser("~"), "Documents", "futbol-analytics-colombia")
RUTA_DATA = os.path.join(BASE, "data")

# ── 1. Tabla de posiciones ────────────────────────────────────
url_posiciones = "https://www.espn.com.co/futbol/posiciones/_/liga/col.1"
response = requests.get(url_posiciones, headers=headers)
soup = BeautifulSoup(response.text, 'html.parser')

# Extraer nombres de equipos
nombres_equipos = [e.text.strip() for e in soup.find_all('span', class_='hide-mobile')]

# Extraer tablas numéricas
dfs = pd.read_html(response.text)

# Unir las dos tablas que trae ESPN
df_izq = dfs[0]   # equipos con abreviatura
df_der = dfs[1]   # estadísticas numéricas

print("Tabla izquierda:")
print(df_izq.head(5))
print("\nTabla derecha:")
print(df_der.head(5))
print(f"\nColumnas derecha: {df_der.columns.tolist()}")

# %%
import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
from datetime import datetime

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}

BASE = os.path.join(os.path.expanduser("~"), "Documents", "futbol-analytics-colombia")
RUTA_DATA = os.path.join(BASE, "data")
RUTA_REPORTS = os.path.join(BASE, "reports")

url = "https://www.espn.com.co/futbol/posiciones/_/liga/col.1"
response = requests.get(url, headers=headers)
soup = BeautifulSoup(response.text, 'html.parser')

# Nombres reales de equipos
nombres = [e.text.strip() for e in soup.find_all('span', class_='hide-mobile')]

# Tablas numéricas
dfs = pd.read_html(response.text)
df_stats = dfs[1]

# Unir nombres con estadísticas
df_final = pd.DataFrame()
df_final['Pos'] = range(1, len(nombres) + 1)
df_final['Equipo'] = nombres
df_final['PJ'] = df_stats['J'].values
df_final['PG'] = df_stats['G'].values
df_final['PE'] = df_stats['E'].values
df_final['PP'] = df_stats['P'].values
df_final['GF'] = df_stats['GF'].values
df_final['GC'] = df_stats['GC'].values
df_final['DIF'] = df_stats['DIF'].values
df_final['PTS'] = df_stats['PTS'].values
df_final['fecha_actualizacion'] = datetime.now().strftime("%Y-%m-%d")

# Guardar
archivo = os.path.join(RUTA_DATA, "tabla_posiciones_betplay.csv")
df_final.to_csv(archivo, index=False)

print("✅ TABLA DE POSICIONES LIGA BETPLAY")
print(f"📅 Actualizada: {datetime.now().strftime('%d/%m/%Y')}")
print(f"{'='*60}")
print(df_final.to_string(index=False))
print(f"\n📁 Guardada en: {archivo}")

# ── Gráfico de posiciones ─────────────────────────────────────
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

fig, axes = plt.subplots(1, 2, figsize=(16, 8))
fig.suptitle(f'Liga BetPlay Colombia — Tabla de Posiciones\n{datetime.now().strftime("%d/%m/%Y")}',
             fontsize=14, fontweight='bold')

# Gráfico 1 — Puntos por equipo
colores = ['gold' if i == 0 else 'silver' if i == 1 else 'chocolate' if i == 2 
           else 'steelblue' for i in range(len(df_final))]
bars = axes[0].barh(df_final['Equipo'][::-1], df_final['PTS'][::-1], color=colores[::-1])
axes[0].set_title('Puntos por Equipo', fontweight='bold')
axes[0].set_xlabel('Puntos')
for bar, pts in zip(bars, df_final['PTS'][::-1]):
    axes[0].text(bar.get_width() + 0.2, bar.get_y() + bar.get_height()/2,
                 str(pts), va='center', fontweight='bold')

# Gráfico 2 — Goles a favor vs en contra
x = range(len(df_final))
width = 0.35
axes[1].bar([i - width/2 for i in x], df_final['GF'], width, label='Goles a favor', color='green', alpha=0.8)
axes[1].bar([i + width/2 for i in x], df_final['GC'], width, label='Goles en contra', color='red', alpha=0.8)
axes[1].set_xticks(list(x))
axes[1].set_xticklabels(df_final['Equipo'], rotation=45, ha='right', fontsize=8)
axes[1].set_title('Goles a Favor vs En Contra', fontweight='bold')
axes[1].legend()

plt.tight_layout()
ruta_grafico = os.path.join(RUTA_REPORTS, f'posiciones_{datetime.now().strftime("%Y%m%d")}.png')
plt.savefig(ruta_grafico, dpi=150, bbox_inches='tight')
plt.show()
print(f"📊 Gráfico guardado")

# %%
import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
from datetime import datetime

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}

BASE = os.path.join(os.path.expanduser("~"), "Documents", "futbol-analytics-colombia")
RUTA_DATA = os.path.join(BASE, "data")

# ── Goleadores ────────────────────────────────────────────────
url_goleadores = "https://www.espn.com.co/futbol/estadisticas/_/liga/col.1/tipo/goles"
response = requests.get(url_goleadores, headers=headers)
print(f"Goleadores - Estado: {response.status_code}")

if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')
    
    try:
        dfs = pd.read_html(response.text)
        print(f"Tablas encontradas: {len(dfs)}")
        for i, df in enumerate(dfs):
            print(f"\nTabla {i}: {df.shape}")
            print(df.head(5))
    except Exception as e:
        print(f"Sin tablas HTML: {e}")
        
    # Buscar nombres de jugadores
    jugadores = soup.find_all('span', class_='hide-mobile')
    print(f"\nJugadores encontrados: {len(jugadores)}")
    for j in jugadores[:15]:
        print(j.text.strip())

# %%
import requests
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from datetime import datetime

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}

BASE = os.path.join(os.path.expanduser("~"), "Documents", "futbol-analytics-colombia")
RUTA_DATA = os.path.join(BASE, "data")
RUTA_REPORTS = os.path.join(BASE, "reports")

# ── 1. Descargar datos reales ─────────────────────────────────
url = "https://www.espn.com.co/futbol/estadisticas/_/liga/col.1/tipo/goles"
response = requests.get(url, headers=headers)
dfs = pd.read_html(response.text)

df_goles = dfs[0].copy()
df_asist = dfs[1].copy()
df_goles.columns = ['POS', 'Nombre', 'Equipo', 'PJ', 'Goles']
df_asist.columns = ['POS', 'Nombre', 'Equipo', 'PJ', 'Asistencias']
df_goles = df_goles.dropna(subset=['Nombre']).reset_index(drop=True)
df_asist = df_asist.dropna(subset=['Nombre']).reset_index(drop=True)
print("Goleadores:", len(df_goles), "| Asistidores:", len(df_asist))

# ── 2. Unir y calcular métricas ───────────────────────────────
df = pd.merge(
    df_goles[['Nombre', 'Equipo', 'PJ', 'Goles']],
    df_asist[['Nombre', 'Asistencias']],
    on='Nombre', how='outer'
).fillna(0)

df['PJ'] = df['PJ'].astype(float)
df['Goles'] = df['Goles'].astype(float)
df['Asistencias'] = df['Asistencias'].astype(float)
df['Goles_p90'] = (df['Goles'] / df['PJ'].replace(0, np.nan)).fillna(0).round(2)
df['Asist_p90'] = (df['Asistencias'] / df['PJ'].replace(0, np.nan)).fillna(0).round(2)
df['Contribuciones'] = df['Goles'] + df['Asistencias']
df['Contribuciones_p90'] = (df['Contribuciones'] / df['PJ'].replace(0, np.nan)).fillna(0).round(2)
df = df[df['PJ'] >= 5].sort_values('Contribuciones', ascending=False).reset_index(drop=True)
print("Jugadores en scouting:", len(df))

# ── 3. Guardar ────────────────────────────────────────────────
archivo = os.path.join(RUTA_DATA, "scouting_jugadores_real.csv")
df.to_csv(archivo, index=False)
print("Guardado en:", archivo)

# ── 4. Tablas en pantalla ─────────────────────────────────────
fecha = datetime.now().strftime('%d/%m/%Y')
sep = "=" * 60

print("\n" + sep)
print("TOP 10 GOLEADORES - Liga BetPlay " + fecha)
print(sep)
print(df.nlargest(10, 'Goles')[['Nombre','Equipo','PJ','Goles','Goles_p90']].to_string(index=False))

print("\n" + sep)
print("TOP 10 ASISTIDORES")
print(sep)
print(df.nlargest(10, 'Asistencias')[['Nombre','Equipo','PJ','Asistencias','Asist_p90']].to_string(index=False))

print("\n" + sep)
print("TOP 10 CONTRIBUCIONES TOTALES")
print(sep)
print(df.nlargest(10, 'Contribuciones')[['Nombre','Equipo','PJ','Goles','Asistencias','Contribuciones','Contribuciones_p90']].to_string(index=False))

# ── 5. Gráfico ────────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(20, 7))
fig.suptitle('Modulo de Scouting - Liga BetPlay Colombia\n' + fecha, fontsize=14, fontweight='bold')

top_g = df.nlargest(10, 'Goles')
axes[0].barh(top_g['Nombre'][::-1], top_g['Goles'][::-1], color='steelblue')
axes[0].set_title('Top 10 Goleadores', fontweight='bold')
axes[0].set_xlabel('Goles')
for i, (g, pj) in enumerate(zip(top_g['Goles'][::-1], top_g['PJ'][::-1])):
    axes[0].text(g + 0.1, i, str(int(g)) + ' (' + str(int(pj)) + 'pj)', va='center', fontsize=8)

top_a = df.nlargest(10, 'Asistencias')
axes[1].barh(top_a['Nombre'][::-1], top_a['Asistencias'][::-1], color='coral')
axes[1].set_title('Top 10 Asistidores', fontweight='bold')
axes[1].set_xlabel('Asistencias')
for i, (a, pj) in enumerate(zip(top_a['Asistencias'][::-1], top_a['PJ'][::-1])):
    axes[1].text(a + 0.1, i, str(int(a)) + ' (' + str(int(pj)) + 'pj)', va='center', fontsize=8)

top_c = df.nlargest(10, 'Contribuciones')
x = range(len(top_c))
axes[2].bar([i - 0.2 for i in x], top_c['Goles'], 0.4, label='Goles', color='steelblue', alpha=0.8)
axes[2].bar([i + 0.2 for i in x], top_c['Asistencias'], 0.4, label='Asistencias', color='coral', alpha=0.8)
axes[2].set_xticks(list(x))
axes[2].set_xticklabels(top_c['Nombre'], rotation=45, ha='right', fontsize=8)
axes[2].set_title('Top 10 Contribuciones', fontweight='bold')
axes[2].legend()

plt.tight_layout()
ruta = os.path.join(RUTA_REPORTS, 'scouting_' + datetime.now().strftime('%Y%m%d') + '.png')
plt.savefig(ruta, dpi=150, bbox_inches='tight')
plt.show()
print("Grafico guardado")

# %%
import requests
import pandas as pd
import numpy as np
from bs4 import BeautifulSoup
import os
from datetime import datetime

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# 1. Scraping de tabla de posiciones
url_pos = "https://www.espn.com.co/futbol/posiciones/_/liga/col.1"
resp = requests.get(url_pos, headers=HEADERS)
soup = BeautifulSoup(resp.text, 'html.parser')
nombres_equipos = [e.text.strip() for e in soup.find_all('span', class_='hide-mobile')]
dfs = pd.read_html(resp.text)
df_stats = dfs[1].copy()
df_stats.columns = ['PJ', 'PG', 'PE', 'PP', 'GF', 'GC', 'DIF', 'PTS']
df_posiciones = pd.DataFrame({
    'Equipo': nombres_equipos[:len(df_stats)],
    'PJ': df_stats['PJ'],
    'PG': df_stats['PG'],
    'PE': df_stats['PE'],
    'PP': df_stats['PP'],
    'GF': df_stats['GF'],
    'GC': df_stats['GC'],
    'DIF': df_stats['DIF'],
    'PTS': df_stats['PTS'],
    'fecha': datetime.now().strftime("%Y-%m-%d")
})

# 2. Scraping de goleadores y asistentes
url_jug = "https://www.espn.com.co/futbol/estadisticas/_/liga/col.1/tipo/goles"
resp2 = requests.get(url_jug, headers=HEADERS)
dfs_jug = pd.read_html(resp2.text)
goles = dfs_jug[0].copy()
asistencias = dfs_jug[1].copy()
goles.columns = ['Rank', 'Nombre', 'Equipo', 'PJ', 'Goles']
asistencias.columns = ['Rank', 'Nombre', 'Equipo', 'PJ', 'Asistencias']
goles = goles.dropna(subset=['Nombre'])
asistencias = asistencias.dropna(subset=['Nombre'])
df_jug = pd.merge(goles[['Nombre', 'Equipo', 'PJ', 'Goles']],
                  asistencias[['Nombre', 'Asistencias']],
                  on='Nombre', how='outer').fillna(0)
df_jug['PJ'] = df_jug['PJ'].astype(float)
df_jug['Goles'] = df_jug['Goles'].astype(float)
df_jug['Asistencias'] = df_jug['Asistencias'].astype(float)

# 3. Simular minutos (mientras no tengas datos reales)
np.random.seed(42)
df_jug['minutos_totales'] = df_jug['PJ'] * np.random.randint(60, 95, len(df_jug))
df_jug['minutos_totales'] = df_jug['minutos_totales'].replace(0, 90)  # evitar división por cero

# 4. Calcular métricas por 90 minutos de forma segura
df_jug['goles_p90'] = (df_jug['Goles'] / (df_jug['minutos_totales'] / 90)).fillna(0)
df_jug['asistencias_p90'] = (df_jug['Asistencias'] / (df_jug['minutos_totales'] / 90)).fillna(0)

# 5. Estadísticas adicionales (simuladas, pero con valores realistas)
df_jug['recuperaciones_p90'] = np.random.exponential(8, len(df_jug)).round(1)
df_jug['duelos_ganados_p90'] = np.random.normal(12, 4, len(df_jug)).clip(2,25).round(1)
df_jug['pases_progresivos_p90'] = np.random.normal(25,10, len(df_jug)).clip(5,60).round(1)

# 6. Limpieza final: eliminar infinitos y NaN
for col in ['goles_p90', 'asistencias_p90', 'recuperaciones_p90', 'duelos_ganados_p90', 'pases_progresivos_p90']:
    df_jug[col] = df_jug[col].replace([np.inf, -np.inf], 0).fillna(0)

print("✅ Datos cargados y limpios")
print(f"Posiciones: {df_posiciones.shape[0]} equipos")
print(f"Jugadores: {df_jug.shape[0]}")
print(f"\nMuestra de jugadores (primeros 5):")
print(df_jug[['Nombre', 'Equipo', 'PJ', 'Goles', 'goles_p90']].head())

# %%
# ==================================================
# MOTOR DE SCOUTING - RECOMENDACIÓN POR SIMILITUD
# ==================================================
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import cosine_similarity
import joblib
import os

# Crear carpeta para modelos si no existe
os.makedirs('models', exist_ok=True)

def entrenar_scouting(df):
    """Entrena el modelo de similitud con los datos actuales"""
    features = ['goles_p90', 'asistencias_p90', 'recuperaciones_p90', 
                'duelos_ganados_p90', 'pases_progresivos_p90']
    X = df[features].values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    joblib.dump(scaler, 'models/scaler_scouting.pkl')
    joblib.dump(df[['Nombre', 'Equipo'] + features], 'models/referencia_scouting.pkl')
    print("✅ Modelo de scouting entrenado")
    return scaler, X_scaled

def recomendar_similares(nombre_jugador, top_n=5):
    """Recomienda jugadores similares al nombre dado"""
    try:
        scaler = joblib.load('models/scaler_scouting.pkl')
        ref = joblib.load('models/referencia_scouting.pkl')
    except:
        print("❌ Modelo no encontrado. Ejecuta primero 'entrenar_scouting(df_jug)'")
        return None
    
    if nombre_jugador not in ref['Nombre'].values:
        print(f"❌ Jugador '{nombre_jugador}' no encontrado en la base")
        print(f"📋 Algunos jugadores disponibles: {ref['Nombre'].head(10).tolist()}")
        return None
    
    features = ['goles_p90', 'asistencias_p90', 'recuperaciones_p90', 
                'duelos_ganados_p90', 'pases_progresivos_p90']
    X = scaler.transform(ref[features].values)
    idx = ref[ref['Nombre'] == nombre_jugador].index[0]
    sim = cosine_similarity([X[idx]], X)[0]
    top_idx = np.argsort(sim)[::-1][1:top_n+1]
    
    resultados = ref.iloc[top_idx][['Nombre', 'Equipo'] + features].copy()
    resultados['similitud'] = sim[top_idx].round(3)
    return resultados

# Entrenar el modelo con los datos actuales
entrenar_scouting(df_jug)

# Ejemplo: recomendar jugadores similares a Andrey Estupiñán (máximo goleador)
print("\n" + "="*60)
print("🔍 JUGADORES SIMILARES A ANDREY ESTUPIÑÁN")
print("="*60)
similares = recomendar_similares("Andrey Estupiñán")
if similares is not None:
    print(similares.to_string(index=False))

# Ejemplo con Dayro Moreno
print("\n" + "="*60)
print("🔍 JUGADORES SIMILARES A DAYRO MORENO")
print("="*60)
similares2 = recomendar_similares("Dayro Moreno")
if similares2 is not None:
    print(similares2.to_string(index=False))

# %%
# ==================================================
# MODELO DE RIESGO DE LESIÓN POR FATIGA
# ==================================================
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score

def generar_datos_lesiones_simulados():
    """Genera dataset sintético basado en lógica deportiva real"""
    np.random.seed(123)
    registros = []
    
    for jugador in range(200):  # 200 jugadores
        # Cada jugador tiene características base
        resistencia_base = np.random.uniform(0.4, 1.0)  # 0.4 = muy fatigable, 1.0 = elite
        propension_lesion = np.random.uniform(0.03, 0.25)
        
        for semana in range(1, 21):  # 20 semanas de temporada
            # Carga de la semana
            minutos_semana = np.random.randint(0, 180)
            # Ratio agudo/crónico (ACWR) - estándar en ciencias del deporte
            carga_cronica = np.random.randint(200, 400)
            acwr = minutos_semana / (carga_cronica / 4 + 0.1)
            acwr = np.clip(acwr, 0.5, 2.5)
            
            # Métricas de intensidad
            sprints = np.random.poisson(minutos_semana / 15)
            aceleraciones = np.random.poisson(minutos_semana / 8)
            
            # Días de descanso desde último partido
            dias_descanso = np.random.choice([1,2,3,4,5,6,7], p=[0.15,0.25,0.3,0.15,0.08,0.04,0.03])
            
            # Fatiga acumulada (modelo simplificado)
            fatiga = (minutos_semana / 90) * (2 - resistencia_base) + max(0, acwr - 1.2) * 1.5
            fatiga = np.clip(fatiga, 0, 4)
            
            # Probabilidad de lesión (modelo del mundo real)
            riesgo = propension_lesion
            riesgo += fatiga * 0.15
            riesgo += max(0, acwr - 1.3) * 0.25  # ACWR > 1.3 es peligroso
            if dias_descanso <= 2:
                riesgo += 0.12
            if minutos_semana > 120:
                riesgo += 0.1
            if sprints > 20:
                riesgo += 0.05
            
            riesgo = np.clip(riesgo, 0, 0.9)
            lesion = 1 if np.random.random() < riesgo else 0
            
            registros.append([jugador, semana, minutos_semana, acwr, sprints, 
                             aceleraciones, dias_descanso, fatiga, lesion])
    
    cols = ['jugador_id', 'semana', 'minutos_semana', 'acwr', 'sprints', 
            'aceleraciones', 'dias_descanso', 'fatiga_acumulada', 'lesion_semana_siguiente']
    df = pd.DataFrame(registros, columns=cols)
    return df

def entrenar_modelo_lesiones():
    """Entrena el modelo de predicción de lesiones"""
    print("🔄 Generando datos de entrenamiento...")
    df = generar_datos_lesiones_simulados()
    
    features = ['minutos_semana', 'acwr', 'sprints', 'aceleraciones', 
                'dias_descanso', 'fatiga_acumulada']
    X = df[features]
    y = df['lesion_semana_siguiente']
    
    # Dividir en entrenamiento y prueba
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Entrenar Random Forest
    modelo = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)
    modelo.fit(X_train, y_train)
    
    # Evaluar
    y_pred = modelo.predict(X_test)
    auc = roc_auc_score(y_test, modelo.predict_proba(X_test)[:, 1])
    
    print(f"✅ Modelo entrenado")
    print(f"   - Precisión global: {modelo.score(X_test, y_test):.2%}")
    print(f"   - AUC ROC: {auc:.3f}")
    print("\n📊 Importancia de variables:")
    for feat, imp in zip(features, modelo.feature_importances_):
        print(f"   - {feat}: {imp:.3f}")
    
    # Guardar modelo
    joblib.dump(modelo, 'models/modelo_lesiones.pkl')
    print("✅ Modelo guardado en 'models/modelo_lesiones.pkl'")
    return modelo

def predecir_riesgo_lesion(minutos_semana, acwr, sprints, aceleraciones, dias_descanso, fatiga_acumulada):
    """Predice el riesgo de lesión para un jugador en una semana"""
    try:
        modelo = joblib.load('models/modelo_lesiones.pkl')
    except:
        print("❌ Modelo no encontrado. Ejecuta primero 'entrenar_modelo_lesiones()'")
        return None, None
    
    entrada = np.array([[minutos_semana, acwr, sprints, aceleraciones, dias_descanso, fatiga_acumulada]])
    prob = modelo.predict_proba(entrada)[0][1]
    
    if prob > 0.6:
        riesgo_texto = "🔴 ALTO"
    elif prob > 0.3:
        riesgo_texto = "🟡 MODERADO"
    else:
        riesgo_texto = "🟢 BAJO"
    
    return prob, riesgo_texto

# Entrenar el modelo (solo la primera vez o si quieres actualizarlo)
if not os.path.exists('models/modelo_lesiones.pkl'):
    entrenar_modelo_lesiones()
else:
    print("✅ Modelo de lesiones ya existe. Si quieres reentrenar, borra 'models/modelo_lesiones.pkl'")

# Ejemplos de predicción
print("\n" + "="*60)
print("⚕️ EJEMPLOS DE PREDICCIÓN DE RIESGO DE LESIÓN")
print("="*60)

# Caso 1: Jugador con carga normal
prob1, riesgo1 = predecir_riesgo_lesion(75, 1.1, 8, 25, 4, 0.8)
print(f"\n📊 Jugador con carga normal:")
print(f"   - Minutos: 75 | ACWR: 1.1 | Sprints: 8 | Descanso: 4 días | Fatiga: 0.8")
print(f"   → Riesgo: {prob1:.1%} {riesgo1}")

# Caso 2: Jugador sobrecargado (alto riesgo)
prob2, riesgo2 = predecir_riesgo_lesion(160, 1.8, 25, 70, 1, 2.5)
print(f"\n⚠️ Jugador con sobrecarga alta:")
print(f"   - Minutos: 160 | ACWR: 1.8 | Sprints: 25 | Descanso: 1 día | Fatiga: 2.5")
print(f"   → Riesgo: {prob2:.1%} {riesgo2}")

# Caso 3: Jugador con descanso adecuado
prob3, riesgo3 = predecir_riesgo_lesion(60, 0.9, 5, 15, 6, 0.4)
print(f"\n✅ Jugador bien descansado:")
print(f"   - Minutos: 60 | ACWR: 0.9 | Sprints: 5 | Descanso: 6 días | Fatiga: 0.4")
print(f"   → Riesgo: {prob3:.1%} {riesgo3}")

# %%
# ==================================================
# GUARDAR REPORTES Y RECOMENDACIONES
# ==================================================

# 1. Guardar tabla de posiciones
df_posiciones.to_csv('data/tabla_posiciones.csv', index=False)
print("✅ Tabla de posiciones guardada")

# 2. Guardar datos de jugadores
df_jug.to_csv('data/jugadores_stats.csv', index=False)
print("✅ Estadísticas de jugadores guardadas")

# 3. Generar recomendaciones para los 5 máximos goleadores
top_goleadores = df_jug.nlargest(5, 'Goles')['Nombre'].tolist()
print("\n" + "="*60)
print("📋 RECOMENDACIONES DE SCOUTING PARA CADA GOLEADOR")
print("="*60)

for goleador in top_goleadores:
    print(f"\n🔥 Basado en: {goleador}")
    similares = recomendar_similares(goleador, top_n=3)
    if similares is not None:
        print(similares[['Nombre', 'Equipo', 'goles_p90', 'similitud']].to_string(index=False))
    print("-"*40)

# 4. Exportar recomendaciones a CSV
recomendaciones_todas = []
for jugador in df_jug['Nombre'].sample(min(20, len(df_jug))):
    sim = recomendar_similares(jugador, top_n=3)
    if sim is not None:
        sim['jugador_base'] = jugador
        recomendaciones_todas.append(sim)

if recomendaciones_todas:
    df_recomendaciones = pd.concat(recomendaciones_todas)
    df_recomendaciones.to_csv('data/recomendaciones_scouting.csv', index=False)
    print("\n✅ Recomendaciones guardadas en 'data/recomendaciones_scouting.csv'")


